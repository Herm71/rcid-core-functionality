<?

/**

 * Custom Sidebars

 *

 * This file contains any custom sidebar registration

 *

 * @package      Core_Functionality

 * @since        1.0.0

 * @link         https://github.com/Herm71/blackbird-core-functionality-plugin.git

 * @author       https://github.com/Herm71

 * @copyright    Copyright (c) 2015, Jason Chafin

 * @license      http://opensource.org/licenses/gpl-2.0.php GNU Public License

 */


